# Block-Surfel Map（B 方案）

替代原 iVox 的连续地图后端。设计目标见模块头文件首部注释。

## 关键文件
- `block_surfel_map.h` — 数据结构与接口
- `block_surfel_map.cc` — 实现（编码、批量更新、Jacobi 特征分解）
- `test_standalone.cpp` — 零依赖单元测试，验证核心算法

## 跑独立测试（不依赖 PCL/Eigen/ROS）
```bash
g++ -std=c++17 -O2 -pthread test_standalone.cpp -o test_sa && ./test_sa
```
预期输出末尾：`=== 26 passed, 0 failed ===`

## 主要参数（写入 yaml 的 `fasterlio:` 节）
| 参数 | 默认 | 含义 |
|---|---|---|
| `ivox_grid_resolution` | 0.5 | cell 边长（保留旧名以兼容） |
| `surfel_min_support` | 5 | cell 累计点数 ≥ 此值才尝试拟合 |
| `surfel_quality_max` | 0.05 | λ_min / Σλ 上限，越小越严苛 |
| `surfel_block_capacity` | 65536 | 最多保留 block 数；每 block = 32 KB |

## 几何常量（编译期）
- `BlockGeom::BX/BY/BZ = 8/8/4` → 256 cell/block
- `sizeof(VoxelCell) = 128B`（1 UltraRAM 元素）
- `sizeof(VoxelBlock) = 32 KB`
