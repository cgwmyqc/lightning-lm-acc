// SPDX-License-Identifier: MIT
// Block-Surfel local map for Lightning-LM.
//
// 设计目标：替代原 iVox，把地图改造成 FPGA 友好的形态。
// 关键属性：
//   1) 写入路径连续：所有更新最终落到 block 内连续的 64B 对齐 cell 数组；
//      block 之间通过哈希目录管理稀疏性。
//   2) 查询无 KNN：观测时直接由 (block_id, cell_id) 索引到 surfel，
//      O(1) 取出预计算的平面参数。
//   3) 写入无原始点近邻依赖：MapIncremental 不再读取最近点列表，
//      转用 cell 自身的统计量 (count/quality/几何中心) 决定是否更新。
//
// Block 几何：8x8x4 = 256 cell/block，cell 边长 = ivox_grid_resolution (默认 0.5m)。
// Cell 大小：64B (一行 cache line)，AoS 排布，对齐 64B。

#pragma once

#include <Eigen/Core>
#include <atomic>
#include <cstdint>
#include <memory>
#include <mutex>
#include <unordered_map>
#include <vector>

#include "common/eigen_types.h"
#include "common/point_def.h"

namespace lightning {

// ---------- Block / Cell 几何常量 ----------
// 改成模板参数会让链接面变复杂，第一版用常量。需要换尺寸时只改这里。
struct BlockGeom {
    static constexpr int BX = 8;   // 块内 X 方向 cell 数
    static constexpr int BY = 8;   // 块内 Y 方向 cell 数
    static constexpr int BZ = 4;   // 块内 Z 方向 cell 数（地面/天花板方向通常更扁）
    static constexpr int CELLS_PER_BLOCK = BX * BY * BZ;  // = 256

    static inline int LocalCellIndex(int lx, int ly, int lz) noexcept {
        // 行优先，FPGA kernel 端约定一致
        return (lz * BY + ly) * BX + lx;
    }
};

// ---------- Cell：64B 对齐、AoS、128B 总长 ----------
// 第一版按 AoS 写，便于和现有 C++ 直接对接；
// 一个 cell = 128B = 32 floats。一个 block (256 cells) 因此恰好是 32 KB，
// 等价于 1 个 UltraRAM 元素（4K×72，288 Kb，约 36 KB 有效），
// 也对应 2 行 cache line。后续 FPGA bitstream 阶段如果要 SoA，再做一次 transform。
struct alignas(64) VoxelCell {
    // 几何统计量（点自由 surfel）
    uint32_t count = 0;       // 累计点数（>= Nmin 才形成有效 surfel）
    uint32_t flags = 0;       // bit0: DIRTY，bit1: VALID_SURFEL
    float sum[3]   = {0, 0, 0};   // Σ p
    // 散布矩阵上三角 (xx, xy, xz, yy, yz, zz)
    float scatter[6] = {0, 0, 0, 0, 0, 0};
    // 预计算 surfel（DIRTY=1 时未更新；查询时若 VALID_SURFEL=0 走 fallback）
    float nx = 0, ny = 0, nz = 0;   // 单位法向
    float d = 0;                     // 平面 nx*x+ny*y+nz*z + d = 0
    float quality = 0;               // λ_min / (λ1+λ2+λ3)；越小平面性越强
    uint32_t last_update_frame = 0;  // 用于淘汰策略（暂未启用）
    float _pad[15] = {0};            // 凑到 128B
};
static_assert(sizeof(VoxelCell) == 128, "VoxelCell must be exactly 128B (1 UltraRAM element)");

enum CellFlag : uint32_t {
    FLAG_DIRTY        = 1u << 0,
    FLAG_VALID_SURFEL = 1u << 1,
};

// ---------- Block：CELLS_PER_BLOCK 个 cell + 头 ----------
// 整块连续 16KB（256 * 64B）。这恰好等于 4 个 BRAM36 cluster，
// 也是后续 DMA burst 的天然单位。
struct alignas(64) VoxelBlock {
    int64_t morton_key = 0;   // 由 (bx,by,bz) 编码而来；调试/导出用
    uint32_t version   = 0;   // 每次任何 cell 更新自增；用于 FPGA 同步
    uint32_t valid_cell_count = 0;
    VoxelCell cells[BlockGeom::CELLS_PER_BLOCK];
};

// ---------- 块键（block 坐标，整数）----------
struct BlockKey {
    int32_t x = 0, y = 0, z = 0;
    bool operator==(const BlockKey& rhs) const noexcept {
        return x == rhs.x && y == rhs.y && z == rhs.z;
    }
};

struct BlockKeyHash {
    // 简单的 xor-mul hash，FPGA 上等价实现成本低
    size_t operator()(const BlockKey& k) const noexcept {
        uint64_t h = static_cast<uint64_t>(k.x) * 73856093u;
        h ^= static_cast<uint64_t>(k.y) * 19349663u;
        h ^= static_cast<uint64_t>(k.z) * 83492791u;
        return static_cast<size_t>(h);
    }
};

// ---------- Surfel 查询结果 ----------
// 查询走的是 O(1) 路径：算出 (block_key, cell_idx)，取一个 cell。
// 若 cell 不满足质量要求，则 valid=false，前端把点丢进 fallback 队列。
struct SurfelCorrespondence {
    bool valid = false;        // 是否有可用 surfel
    Vec4f plane = Vec4f::Zero(); // (nx, ny, nz, d)
    Vec3f centroid = Vec3f::Zero();
    float quality = 0;
    uint32_t count = 0;
};

// ---------- 配置 ----------
struct BlockSurfelMapOptions {
    float cell_resolution = 0.5f;      // 与原 ivox_grid_resolution 同义
    int   min_support     = 5;         // count 达到此值才尝试拟合平面
    float quality_max     = 0.05f;     // λ_min/Σλ 上限；超过则 surfel 不可信
    size_t block_capacity = 65536;     // 最多保留的 block 数；用作 LRU 上限
    bool   enable_fallback = true;     // 是否启用 KNN 回退（暂留接口）
};

// ---------- 主类 ----------
// 线程模型：
//   - ObsModel 内的 Lookup 是只读，可被多线程并发调用（block 已存在）。
//   - MapIncremental 内的 BatchUpdate 是单线程批量写入。
//   - 第一版不让 lookup 和 update 真正并行（按 Run() 顺序串行调用），
//     所以内部不放每 block 锁。后续上 FPGA 时这个边界更清楚。
class BlockSurfelMap {
public:
    using KeyType = BlockKey;

    explicit BlockSurfelMap(const BlockSurfelMapOptions& opt);

    // 批量写入：内部会先把点编码成 (block_key, cell_idx)，
    // 排序后按 block 连续累加；这是 MapIncremental 的新主路径。
    void BatchUpdate(const PointVector& points_world);

    // 首帧写入：与 BatchUpdate 等价，但显式表明语义
    void Initialize(const PointVector& points_world) { BatchUpdate(points_world); }

    // 单点查询 surfel；O(1)
    bool LookupSurfel(const PointType& pt_world, SurfelCorrespondence& out) const;

    // 当查询失败时，把点送进 fallback 队列；预留接口给 D 方案回退
    // 第一版不真正实现 KNN 回退，只是统计；这样可以独立观察 surfel 是否够用
    void EnqueueFallback(const PointType& pt_world);
    size_t FallbackCount() const { return fallback_count_.load(); }
    void   ResetFallbackCount() { fallback_count_.store(0); }

    // 触发所有 dirty cell 重新拟合 surfel；BatchUpdate 已自动调用
    // 单独暴露用于离线调试
    void RecomputeDirtySurfels();

    // 统计
    size_t NumBlocks() const { return blocks_.size(); }
    size_t NumValidCells() const;
    size_t NumValidSurfels() const;
    const BlockSurfelMapOptions& Options() const { return options_; }

    // 调试导出：把所有 surfel 的 centroid 拼成点云，给 SaveMap/可视化用
    // 不参与热路径
    void ExportCentroidCloud(PointVector& out) const;

private:
    // 把世界点坐标量化到 (block_key, local_cell_index)
    // 内联，FPGA 端逻辑等价
    void Encode(const Vec3f& p, BlockKey& bk, int& cell_idx) const noexcept;

    // 取 block（不存在则创建）
    VoxelBlock& GetOrCreateBlock(const BlockKey& k);

    // 用 cell 累计统计量拟合 surfel；只更新一个 cell
    static void FitSurfel(VoxelCell& c, float quality_max);

private:
    BlockSurfelMapOptions options_;
    float inv_resolution_ = 0.0f;
    float block_size_world_x_ = 0.0f;  // = BX * cell_resolution
    float block_size_world_y_ = 0.0f;
    float block_size_world_z_ = 0.0f;
    float inv_block_size_x_ = 0.0f;
    float inv_block_size_y_ = 0.0f;
    float inv_block_size_z_ = 0.0f;

    std::unordered_map<BlockKey, std::unique_ptr<VoxelBlock>, BlockKeyHash> blocks_;

    uint32_t current_frame_ = 0;  // 每帧 BatchUpdate 自增；用于 last_update_frame

    mutable std::atomic<size_t> fallback_count_{0};
};

}  // namespace lightning
