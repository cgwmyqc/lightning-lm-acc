// SPDX-License-Identifier: MIT
// BlockSurfelMap implementation.
//
// 实现要点：
//  - Encode 用 std::floor + 整数取模，保证负坐标也对（round 会把 -0.4 round 到 0，
//    再对 BX 取模会得到错误的 cell idx）。
//  - BatchUpdate 内排序键是 (block_key_hash, cell_idx)；排序的目的是让对同一 block
//    的写入挨在一起，这是后续 FPGA DMA burst 的前提。CPU 上这步只有 O(N log N)，
//    20k 点级别开销可忽略。
//  - 特征分解走 3x3 对称 Jacobi 旋转，固定迭代次数 8 次；这是 FPGA 友好版本，
//    精度足够拟合平面（残差量级 < 1e-5）。
//  - 不在 lookup 路径里访问 unordered_map 的 default-constructed 项（用 find 而非 [])，
//    否则只读查询会偷偷创建空 block。

#include "block_surfel_map.h"

#include <glog/logging.h>
#include <algorithm>
#include <cmath>
#include <execution>

namespace lightning {

// ============================================================================
// 构造与几何参数
// ============================================================================

BlockSurfelMap::BlockSurfelMap(const BlockSurfelMapOptions& opt) : options_(opt) {
    CHECK_GT(options_.cell_resolution, 0.0f);
    inv_resolution_ = 1.0f / options_.cell_resolution;

    block_size_world_x_ = BlockGeom::BX * options_.cell_resolution;
    block_size_world_y_ = BlockGeom::BY * options_.cell_resolution;
    block_size_world_z_ = BlockGeom::BZ * options_.cell_resolution;
    inv_block_size_x_ = 1.0f / block_size_world_x_;
    inv_block_size_y_ = 1.0f / block_size_world_y_;
    inv_block_size_z_ = 1.0f / block_size_world_z_;

    LOG(INFO) << "[BlockSurfelMap] cell_res=" << options_.cell_resolution
              << " block_size=(" << block_size_world_x_ << ","
              << block_size_world_y_ << "," << block_size_world_z_ << ")"
              << " cells/block=" << BlockGeom::CELLS_PER_BLOCK
              << " min_support=" << options_.min_support
              << " quality_max=" << options_.quality_max;
}

// ============================================================================
// 编码：world point -> (block_key, local_cell_index)
// ============================================================================

inline void BlockSurfelMap::Encode(const Vec3f& p, BlockKey& bk, int& cell_idx) const noexcept {
    // 用 floor 而不是 round，避免负坐标边界 cell 错位
    const float gx_f = std::floor(p.x() * inv_resolution_);
    const float gy_f = std::floor(p.y() * inv_resolution_);
    const float gz_f = std::floor(p.z() * inv_resolution_);

    const int gx = static_cast<int>(gx_f);
    const int gy = static_cast<int>(gy_f);
    const int gz = static_cast<int>(gz_f);

    // 用 div_floor 把 cell 坐标分解为 block 坐标 + 局部坐标
    // C++ 的整数除法对负数向 0 取整，不是向下；得手动修正
    auto div_floor = [](int a, int b) -> int {
        int q = a / b;
        int r = a - q * b;
        if ((r != 0) && ((r < 0) != (b < 0))) --q;
        return q;
    };
    auto mod_floor = [](int a, int b) -> int {
        int r = a % b;
        if ((r != 0) && ((r < 0) != (b < 0))) r += b;
        return r;
    };

    bk.x = div_floor(gx, BlockGeom::BX);
    bk.y = div_floor(gy, BlockGeom::BY);
    bk.z = div_floor(gz, BlockGeom::BZ);

    const int lx = mod_floor(gx, BlockGeom::BX);
    const int ly = mod_floor(gy, BlockGeom::BY);
    const int lz = mod_floor(gz, BlockGeom::BZ);
    cell_idx = BlockGeom::LocalCellIndex(lx, ly, lz);
}

// ============================================================================
// Block 取或建
// ============================================================================

VoxelBlock& BlockSurfelMap::GetOrCreateBlock(const BlockKey& k) {
    auto it = blocks_.find(k);
    if (it != blocks_.end()) return *it->second;

    // capacity 控制：超过上限时随机驱逐（第一版简单做，未跑 LRU）
    if (blocks_.size() >= options_.block_capacity) {
        blocks_.erase(blocks_.begin());
    }

    auto blk = std::make_unique<VoxelBlock>();
    // morton_key 用 (z<<42)|(y<<21)|x 简化版编码，仅供调试
    blk->morton_key = (static_cast<int64_t>(k.z) << 42) |
                      (static_cast<int64_t>(k.y & 0x1FFFFF) << 21) |
                      static_cast<int64_t>(k.x & 0x1FFFFF);
    auto* ptr = blk.get();
    blocks_.emplace(k, std::move(blk));
    return *ptr;
}

// ============================================================================
// FitSurfel：3x3 对称矩阵 Jacobi 特征分解（固定 8 次迭代）
// ============================================================================
//
// 协方差 C = scatter/N - centroid * centroid^T
// 平面法向 = 最小特征值对应的特征向量
// quality = lambda_min / (lambda1+lambda2+lambda3)，越小越像平面
//
// Jacobi 旋转每次消除一个非对角项；3x3 矩阵 8 次扫描足够收敛到 1e-7 量级。
// 这个实现的好处是无分支、无除零保护以外的分支、可直接对应到 FPGA 状态机。

void BlockSurfelMap::FitSurfel(VoxelCell& c, float quality_max) {
    if (c.count < 3) {
        c.flags &= ~FLAG_VALID_SURFEL;
        c.flags &= ~FLAG_DIRTY;
        return;
    }
    const float inv_n = 1.0f / static_cast<float>(c.count);
    const float cx = c.sum[0] * inv_n;
    const float cy = c.sum[1] * inv_n;
    const float cz = c.sum[2] * inv_n;

    // 协方差 C 用 3x3 数组储存，便于循环索引
    // C[i][j] = scatter[i,j]/N - centroid_i * centroid_j
    float A[3][3];
    A[0][0] = c.scatter[0] * inv_n - cx * cx;
    A[0][1] = c.scatter[1] * inv_n - cx * cy;
    A[0][2] = c.scatter[2] * inv_n - cx * cz;
    A[1][0] = A[0][1];
    A[1][1] = c.scatter[3] * inv_n - cy * cy;
    A[1][2] = c.scatter[4] * inv_n - cy * cz;
    A[2][0] = A[0][2];
    A[2][1] = A[1][2];
    A[2][2] = c.scatter[5] * inv_n - cz * cz;

    // V 累积特征向量；初始为单位阵
    float V[3][3] = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}};

    // 标准 3x3 对称 Jacobi：每个 sweep 处理 (0,1),(0,2),(1,2) 三个非对角元
    // 固定 8 次 sweep 在 float 精度下足够收敛；FPGA 端直接展开成状态机即可
    for (int sweep = 0; sweep < 8; ++sweep) {
        for (int pq = 0; pq < 3; ++pq) {
            int p, q;
            if (pq == 0) { p = 0; q = 1; }
            else if (pq == 1) { p = 0; q = 2; }
            else              { p = 1; q = 2; }

            float apq = A[p][q];
            if (std::fabs(apq) < 1e-20f) continue;
            float app = A[p][p];
            float aqq = A[q][q];

            // 计算 tan(theta) = t
            float diff = aqq - app;
            float t;
            if (std::fabs(diff) > 1e6f * std::fabs(apq)) {
                t = apq / diff;
            } else {
                float theta = 0.5f * diff / apq;
                t = 1.0f / (std::fabs(theta) + std::sqrt(1.0f + theta * theta));
                if (theta < 0) t = -t;
            }
            float cs = 1.0f / std::sqrt(1.0f + t * t);
            float sn = t * cs;

            // 更新 A：先处理主对角
            A[p][p] = app - t * apq;
            A[q][q] = aqq + t * apq;
            A[p][q] = 0;
            A[q][p] = 0;

            // 第三行/列 (索引 i != p, q) 的更新
            for (int i = 0; i < 3; ++i) {
                if (i == p || i == q) continue;
                float aip = A[i][p];
                float aiq = A[i][q];
                A[i][p] = cs * aip - sn * aiq;
                A[i][q] = sn * aip + cs * aiq;
                A[p][i] = A[i][p];
                A[q][i] = A[i][q];
            }

            // 累积特征向量 V <- V * R(p,q)
            for (int i = 0; i < 3; ++i) {
                float vip = V[i][p];
                float viq = V[i][q];
                V[i][p] = cs * vip - sn * viq;
                V[i][q] = sn * vip + cs * viq;
            }
        }
    }

    // 现在 A[i][i] 是三个特征值，V 的第 i 列是对应特征向量
    float l[3] = {A[0][0], A[1][1], A[2][2]};
    int min_idx = 0;
    if (l[1] < l[min_idx]) min_idx = 1;
    if (l[2] < l[min_idx]) min_idx = 2;
    float lmin = l[min_idx];
    float trace = l[0] + l[1] + l[2];
    if (trace < 1e-12f) {
        c.flags &= ~FLAG_VALID_SURFEL;
        c.flags &= ~FLAG_DIRTY;
        return;
    }
    float quality = lmin / trace;  // 越小越平
    if (quality > quality_max) {
        c.flags &= ~FLAG_VALID_SURFEL;
        c.flags &= ~FLAG_DIRTY;
        c.quality = quality;
        return;
    }

    float nx = V[0][min_idx];
    float ny = V[1][min_idx];
    float nz = V[2][min_idx];

    float nrm = std::sqrt(nx * nx + ny * ny + nz * nz);
    if (nrm < 1e-12f) {
        c.flags &= ~FLAG_VALID_SURFEL;
        c.flags &= ~FLAG_DIRTY;
        return;
    }
    nx /= nrm; ny /= nrm; nz /= nrm;
    // 法向方向取正向：让法向指向坐标原点的反向，保持稳定（可选）
    // 这里保持原始方向；ESKF 的点面残差只用 |n·p + d|，正负不敏感
    c.nx = nx; c.ny = ny; c.nz = nz;
    c.d = -(nx * cx + ny * cy + nz * cz);
    c.quality = quality;
    c.flags |= FLAG_VALID_SURFEL;
    c.flags &= ~FLAG_DIRTY;
}

// ============================================================================
// 批量更新：MapIncremental 的新主路径
// ============================================================================

void BlockSurfelMap::BatchUpdate(const PointVector& points_world) {
    if (points_world.empty()) return;
    ++current_frame_;

    const int N = static_cast<int>(points_world.size());
    struct Entry {
        BlockKey bk;
        int cell_idx;
        int point_idx;
        size_t block_hash;
    };
    std::vector<Entry> entries(N);
    BlockKeyHash hasher;

    // 1) 编码 + 算 hash
    for (int i = 0; i < N; ++i) {
        Entry& e = entries[i];
        e.point_idx = i;
        Encode(points_world[i].getVector3fMap(), e.bk, e.cell_idx);
        e.block_hash = hasher(e.bk);
    }

    // 2) 按 block 排序，让连续累加成为 burst-friendly 模式
    //    排序键：先按 hash 把同 block 的点聚到一起，再按 cell_idx 聚拢同 cell
    //    （hash 等价相当于 block 划分；FPGA 端等价于按 block id 分组）
    std::sort(entries.begin(), entries.end(),
              [](const Entry& a, const Entry& b) {
                  if (a.block_hash != b.block_hash) return a.block_hash < b.block_hash;
                  if (!(a.bk == b.bk)) {
                      // hash 冲突时按真实 key 进一步排序
                      if (a.bk.x != b.bk.x) return a.bk.x < b.bk.x;
                      if (a.bk.y != b.bk.y) return a.bk.y < b.bk.y;
                      return a.bk.z < b.bk.z;
                  }
                  return a.cell_idx < b.cell_idx;
              });

    // 3) 分段扫描：同一 block 内的所有点连续写入；FPGA 上这对应一次 block load + 多次 cell 累加 + 一次 block flush
    int i = 0;
    while (i < N) {
        const BlockKey bk = entries[i].bk;
        VoxelBlock& blk = GetOrCreateBlock(bk);

        int j = i;
        while (j < N && entries[j].bk == bk) {
            const int cidx = entries[j].cell_idx;
            const PointType& p = points_world[entries[j].point_idx];
            VoxelCell& c = blk.cells[cidx];
            // 累加点自由统计量
            if (c.count == 0) blk.valid_cell_count++;
            c.count++;
            c.sum[0] += p.x; c.sum[1] += p.y; c.sum[2] += p.z;
            c.scatter[0] += p.x * p.x;
            c.scatter[1] += p.x * p.y;
            c.scatter[2] += p.x * p.z;
            c.scatter[3] += p.y * p.y;
            c.scatter[4] += p.y * p.z;
            c.scatter[5] += p.z * p.z;
            c.flags |= FLAG_DIRTY;
            c.last_update_frame = current_frame_;
            ++j;
        }
        blk.version++;
        i = j;
    }

    // 4) 重新拟合本帧动过的 cell —— 与上一步在同一段连续内存上做
    RecomputeDirtySurfels();
}

// ============================================================================
// 重新拟合所有 dirty cell
// ============================================================================

void BlockSurfelMap::RecomputeDirtySurfels() {
    // 把 block 指针拍平，便于 parallel
    std::vector<VoxelBlock*> blk_ptrs;
    blk_ptrs.reserve(blocks_.size());
    for (auto& kv : blocks_) blk_ptrs.push_back(kv.second.get());

    const int min_support = options_.min_support;
    const float qmax = options_.quality_max;

    std::for_each(std::execution::par_unseq, blk_ptrs.begin(), blk_ptrs.end(),
                  [min_support, qmax](VoxelBlock* blk) {
                      for (int i = 0; i < BlockGeom::CELLS_PER_BLOCK; ++i) {
                          VoxelCell& c = blk->cells[i];
                          if (!(c.flags & FLAG_DIRTY)) continue;
                          if (c.count < static_cast<uint32_t>(min_support)) {
                              // count 不够也清掉 DIRTY，避免反复尝试
                              c.flags &= ~FLAG_DIRTY;
                              c.flags &= ~FLAG_VALID_SURFEL;
                              continue;
                          }
                          FitSurfel(c, qmax);
                      }
                  });
}

// ============================================================================
// 单点查询
// ============================================================================

bool BlockSurfelMap::LookupSurfel(const PointType& pt_world, SurfelCorrespondence& out) const {
    BlockKey bk;
    int cell_idx;
    Encode(pt_world.getVector3fMap(), bk, cell_idx);

    auto it = blocks_.find(bk);
    if (it == blocks_.end()) {
        out.valid = false;
        return false;
    }
    const VoxelCell& c = it->second->cells[cell_idx];
    if (!(c.flags & FLAG_VALID_SURFEL)) {
        out.valid = false;
        return false;
    }
    out.valid = true;
    out.plane = Vec4f(c.nx, c.ny, c.nz, c.d);
    const float inv_n = 1.0f / static_cast<float>(c.count);
    out.centroid = Vec3f(c.sum[0] * inv_n, c.sum[1] * inv_n, c.sum[2] * inv_n);
    out.quality = c.quality;
    out.count = c.count;
    return true;
}

void BlockSurfelMap::EnqueueFallback(const PointType& /*pt_world*/) {
    // 第一版只统计，不真正回退到 KNN；待 surfel 命中率稳定后再实现 D 路径
    fallback_count_.fetch_add(1, std::memory_order_relaxed);
}

// ============================================================================
// 统计 / 导出
// ============================================================================

size_t BlockSurfelMap::NumValidCells() const {
    size_t n = 0;
    for (auto& kv : blocks_) n += kv.second->valid_cell_count;
    return n;
}

size_t BlockSurfelMap::NumValidSurfels() const {
    size_t n = 0;
    for (auto& kv : blocks_) {
        for (int i = 0; i < BlockGeom::CELLS_PER_BLOCK; ++i) {
            if (kv.second->cells[i].flags & FLAG_VALID_SURFEL) ++n;
        }
    }
    return n;
}

void BlockSurfelMap::ExportCentroidCloud(PointVector& out) const {
    out.clear();
    out.reserve(NumValidSurfels());
    for (auto& kv : blocks_) {
        for (int i = 0; i < BlockGeom::CELLS_PER_BLOCK; ++i) {
            const VoxelCell& c = kv.second->cells[i];
            if (!(c.flags & FLAG_VALID_SURFEL)) continue;
            const float inv_n = 1.0f / static_cast<float>(c.count);
            PointType p;
            p.x = c.sum[0] * inv_n;
            p.y = c.sum[1] * inv_n;
            p.z = c.sum[2] * inv_n;
            p.intensity = c.quality;
            out.push_back(p);
        }
    }
}

}  // namespace lightning
